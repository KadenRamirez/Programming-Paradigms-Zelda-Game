/*
* Kaden Ramirez
* 3/10/2023
* Link and map interaction- create a map using tiles. This map could then be saved, loaded, and adjusted as necessary by a click of the mouse
*				but only in the edit mode. Moreover, using the w,a,x,d keys you can move the view up, left, down, and right respectively.
*				The map will also not let you go out of the bounds using these keys set. Moreover, link is now featured in the program. 
*				He is animated and can interact with the tiles and switch screens when needed. Added pots and boomerang interaction to the program.
*				
*/

import java.awt.Graphics;
import java.awt.image.BufferedImage;

enum Direction{
	LEFT(1),
	RIGHT(2),
	UP(3),
	DOWN(0);

	public final int direction;

	private Direction(int d){
		this.direction = d;
	}
}

public class Link extends Sprite{

	// int x, y, prevx, prevy;
	// static final int w = 50, h = 50; //width and height of Link
	//int prevx, prevy;
	final int NUM_IMAGES = 28;
	final int MAX_IMAGES = 7; //number of images in each direction
	Direction heading;
	BufferedImage image;
	BufferedImage[] images;
	int currentImage;

	public Link(int x, int y){
		this.x = x;
		this.y = y;
		w = 50;
		h = 50;

		heading = Direction.DOWN;
		//System.out.println(heading);
		/*if(image == null){
			image = View.loadImage("images/link1.png");
		}*/
		
		images = new BufferedImage[NUM_IMAGES];
		for(int i = 1; i <= 28; i++){
			images[i-1] = View.loadImage("images/link" + (i) + ".png");
		}
		currentImage = 0;
	}

	public Json marshal()
    {
        Json ob = Json.newObject();
        ob.add("x", this.x);
        ob.add("y", this.y);
        return ob;
    }

	public void animate(Direction dir){
		//down 1-7
		//left 8 - 14
		//right 15 - 21
		//up 22 - 28

		heading = dir;
		currentImage++;
		if(currentImage >= MAX_IMAGES){
			currentImage = 0;
		}
	}

	public void setPreviousCoordinates(int x, int y){
		this.prevx = x;
		this.prevy = y;
	}

	public void draw(Graphics g, int scrollPosX, int scrollPosY){
		g.drawImage(images[currentImage + 7 * heading.direction], x - scrollPosX, y - scrollPosY, w, h, null);
	}

	public boolean isLink(){
		return true;
	}

	public void update(){}
}