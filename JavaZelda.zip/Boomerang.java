/*
* Kaden Ramirez
* 3/10/2023
* Link and map interaction- create a map using tiles. This map could then be saved, loaded, and adjusted as necessary by a click of the mouse
*               but only in the edit mode. Moreover, using the w,a,x,d keys you can move the view up, left, down, and right respectively.
*               The map will also not let you go out of the bounds using these keys set. Moreover, link is now featured in the program. 
*               He is animated and can interact with the tiles and switch screens when needed. Added pots and boomerang interaction to the program.
*               
*/

import java.awt.Graphics;
import java.awt.image.BufferedImage;

public class Boomerang extends Sprite{

	// int w = 50;
    // int h = 50;
	// int x;
	// int y;
    // BufferedImage tile_image;

	public Boomerang(int x, int y, int dir) {
        this.x = x;
        this.y = y;
        speed = dir;
        w = 30;
        h = 30;
        System.out.println("the boomerang constructor is being called");
        image = null;
        if(image == null){
            System.out.println("The boomerang image is being loaded");
            image = View.loadImage("images/boomerang1.png");
        }
    }

    public boolean isClicked(int x, int y){
    	if(this.x == x && this.y == y){
    		return true;
    	}
    	return false;
    }

    //marshal constructor
    public Json marshal()
    {
        Json ob = Json.newObject();
        ob.add("x", x);
        ob.add("y", y);
        return ob;
    }

    //unmarshal constructor
    Boomerang(Json ob)
    {
        x = (int)ob.getLong("x");
        y = (int)ob.getLong("y");
        w = 30;
        h = 30;
        speed = 0;
        //System.out.println("this is t.x: " + x + " this is t.y: " + y + " this is t.w: " + w + " this is t.h: " + h);
        image = null;
        if(image == null){
            image = View.loadImage("images/boomerang1.png");
        }
    }

    public void draw(Graphics g, int scrollPosX, int scrollPosY) {
        g.drawImage(image, x - scrollPosX, y - scrollPosY, w, h, null);
    }

    public boolean isBoomerang(){
        return true;
    }

    public void setPreviousCoordinates(int x, int y){
        this.prevx = x;
        this.prevy = y;
    }

    public void update(){
        if(speed == 1){
            x -= 8;
        }if(speed == 2){
            x += 8;
        }
        if(speed == 3){
            y -= 8;
        }
        if(speed == 0){
            y += 8;
        }
    }

}