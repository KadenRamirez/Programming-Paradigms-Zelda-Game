/*
* Kaden Ramirez
* 3/10/2023
* Link and map interaction- create a map using tiles. This map could then be saved, loaded, and adjusted as necessary by a click of the mouse
*               but only in the edit mode. Moreover, using the w,a,x,d keys you can move the view up, left, down, and right respectively.
*               The map will also not let you go out of the bounds using these keys set. Moreover, link is now featured in the program. 
*               He is animated and can interact with the tiles and switch screens when needed. Added pots and boomerang interaction to the program.
*               
*/

import java.awt.Graphics;
import java.awt.image.BufferedImage;

public class Tile extends Sprite{

	// int w = 50;
    // int h = 50;
	// int x;
	// int y;
    // BufferedImage tile_image;

	public Tile(int x, int y) {
        this.x = x;
        this.y = y;
        w = 50;
        h = 50;
        System.out.println("the tile constructor is being called");
        image = null;
        if(image == null){
            System.out.println("The tile image is being loaded");
            image = View.loadImage("images/tile.jpg");
        }
    }

    public boolean isClicked(int x, int y){
    	if(this.x == x && this.y == y){
    		return true;
    	}
    	return false;
    }

    //marshal constructor
    public Json marshal()
    {
        Json ob = Json.newObject();
        ob.add("x", x);
        ob.add("y", y);
        return ob;
    }

    //unmarshal constructor
    Tile(Json ob)
    {
        x = (int)ob.getLong("x");
        y = (int)ob.getLong("y");
        w = 50;
        h = 50;
        //System.out.println("this is t.x: " + x + " this is t.y: " + y + " this is t.w: " + w + " this is t.h: " + h);
        image = null;
        if(image == null){
            image = View.loadImage("images/tile.jpg");
        }
    }

    public void setPreviousCoordinates(int x, int y){
        this.prevx = x;
        this.prevy = y;
    }

    public void draw(Graphics g, int scrollPosX, int scrollPosY) {
        g.drawImage(image, x - scrollPosX, y - scrollPosY, w, h, null);
    }

    public boolean isTile(){
        return true;
    }

    public void update(){}

}