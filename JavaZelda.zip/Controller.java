/*
* Kaden Ramirez
* 3/10/2023
* Link and map interaction- create a map using tiles. This map could then be saved, loaded, and adjusted as necessary by a click of the mouse
*				but only in the edit mode. Moreover, using the w,a,x,d keys you can move the view up, left, down, and right respectively.
*				The map will also not let you go out of the bounds using these keys set. Moreover, link is now featured in the program. 
*				He is animated and can interact with the tiles and switch screens when needed. Added pots and boomerang interaction to the program.
*				
*/


import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.KeyListener;
import java.awt.event.KeyEvent;

class Controller implements ActionListener, MouseListener, KeyListener
{
	View view;
	Model model;
	boolean keyLeft;
	boolean keyRight;
	boolean keyUp;
	boolean keyDown;
	boolean wasRemoved;
	boolean isEdit;
	boolean editPot;

	Controller(Model m)
	{
		model = m;
		//model = new Model(Json.load("map.json"));
		//view.setModel(model);

		isEdit = false;
		editPot = false;
		wasRemoved = false;
	}

	public void actionPerformed(ActionEvent e)
	{
		//view.removeButton();
	}

	void setView(View v){
    	view = v;
	}

	void setModel(Model m){
		model = m;
	}

	public void mousePressed(MouseEvent e)
	{
		//model.setDestination(e.getX(), e.getY());
		if(isEdit){
			for(int i = 0; i < model.sprites.size(); i++)
			{
				Sprite s = model.sprites.get(i);
				if(s.isClicked(e.getX() - (e.getX() % 50 - view.scrollPosX), e.getY() - (e.getY() % 50 - view.scrollPosY))){
					model.sprites.remove(i);
					wasRemoved = true;
				}
			}
			if(!wasRemoved){
				if(!editPot){
					model.addTile(e.getX() - (e.getX() % 50 - view.scrollPosX), e.getY() - (e.getY() % 50 - view.scrollPosY));
				}else{
					model.addPot(e.getX() - (e.getX() % 50 - view.scrollPosX) + 5, e.getY() - (e.getY() % 50 - view.scrollPosY) + 5);
				}
			}
		}
		wasRemoved = false;
	}

	public void mouseReleased(MouseEvent e) {    }
	public void mouseEntered(MouseEvent e) {    }
	public void mouseExited(MouseEvent e) {    }
	public void mouseClicked(MouseEvent e) {    }

	public void keyPressed(KeyEvent e)
	{
		switch(e.getKeyCode())
		{
			case KeyEvent.VK_RIGHT:
				keyRight = true;
				model.link.animate(Direction.RIGHT);
				break;
			case KeyEvent.VK_LEFT:
				keyLeft = true;
				model.link.animate(Direction.LEFT);
				break;
			case KeyEvent.VK_UP:
				keyUp = true;
				model.link.animate(Direction.UP);
				break;
			case KeyEvent.VK_DOWN:
				keyDown = true;
				model.link.animate(Direction.DOWN);
				break;
		}
	}

	public void keyReleased(KeyEvent e)
	{
		switch(e.getKeyCode())
		{
			case KeyEvent.VK_RIGHT:
				keyRight = false;
				break;
			case KeyEvent.VK_LEFT:
				keyLeft = false;
				break;
			case KeyEvent.VK_UP:
				keyUp = false;
				break;
			case KeyEvent.VK_DOWN:
				keyDown = false;
				break;
			case KeyEvent.VK_ESCAPE:
				System.exit(0);
			case KeyEvent.VK_CONTROL:
				model.addBoomerang(model.link.x + 5, model.link.y + 10);
				break;
		}
		char c = Character.toLowerCase(e.getKeyChar());
		switch(c){
			case 'q':
				System.exit(0);
				break;
			case 's':
				model.marshal();
				break;
			case 'l':
				model = new Model(Json.load("map.json"));
				this.setModel(model);
				view.setModel(model);
				break;
			case 'w':
				if(isEdit){
					view.scrollUp();
				}
				break;
			case 'x':
				if(isEdit){
					view.scrollDown();
				}
				break;
			case 'a':
				if(isEdit){
					view.scrollLeft();
				}
				break;
			case 'd':
				if(isEdit){
					view.scrollRight();
				}
				break;
			case 'e':
				isEdit = !isEdit;
				break;
			case'p':
				editPot = !editPot;
				break;
		}
	}

	public void keyTyped(KeyEvent e)
	{
	}

	void update()
	{
		//model.link.setPreviousCoordinates(model.link.x, model.link.y);
		for(int i = 0; i < model.sprites.size(); i++){
			model.sprites.get(i).setPreviousCoordinates(model.sprites.get(i).x, model.sprites.get(i).y);
		}
		if(keyRight){
			model.link.x+=4;
			if(model.link.x + model.link.w > 700 && model.link.prevx + model.link.w <= 700){
				view.scrollRight();
			}
		}
		if(keyLeft){
			model.link.x-=4;
			if(model.link.x < 700 && model.link.prevx >= 700){
				view.scrollLeft();
			}
		}
		if(keyDown){
			model.link.y+=4;
			if(model.link.y + model.link.h > 500 && model.link.prevy + model.link.h <= 500){
				view.scrollDown();
			}
		}
		if(keyUp){
			model.link.y-=4;
			if(model.link.y < 500 && model.link.prevy >= 500){
				view.scrollUp();
			}
		}
	}

}
