/*
* Kaden Ramirez
* 3/10/2023
* Link and map interaction- create a map using tiles. This map could then be saved, loaded, and adjusted as necessary by a click of the mouse
*				but only in the edit mode. Moreover, using the w,a,x,d keys you can move the view up, left, down, and right respectively.
*				The map will also not let you go out of the bounds using these keys set. Moreover, link is now featured in the program. 
*				He is animated and can interact with the tiles and switch screens when needed. Added pots and boomerang interaction to the program.
*				
*/


import javax.swing.JFrame;
import java.awt.Toolkit;

public class Game extends JFrame
{
	Model model;
	Tile tile;
	Controller controller;
	View view;
	Link link;
	public Game()
	{
		model = new Model(Json.load("map.json"));
		controller = new Controller(model);
		view = new View(controller, model);
		//link = new Link(200, 200);
		controller.setView(view);
		view.addMouseListener(controller);
		this.addKeyListener(controller);
		this.setTitle("Zelda?");
		this.setSize(700, 500);
		this.setFocusable(true);
		this.getContentPane().add(view);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);
	}

	public static void main(String[] args)
	{
		Game g = new Game();
		g.run();
	}

	public void run(){
		while(true)
		{
			controller.update();
			model.update();
			//tile.update();
			view.repaint(); // This will indirectly call View.paintComponent
			Toolkit.getDefaultToolkit().sync(); // Updates screen

			// Go to sleep for 50 milliseconds
			try
			{
				Thread.sleep(50);
			} catch(Exception e) {
				e.printStackTrace();
				System.exit(1);
			}
		}
	}

	void update(){}
}
