/*
* Kaden Ramirez
* 3/10/2023
* Link and map interaction- create a map using tiles. This map could then be saved, loaded, and adjusted as necessary by a click of the mouse
*				but only in the edit mode. Moreover, using the w,a,x,d keys you can move the view up, left, down, and right respectively.
*				The map will also not let you go out of the bounds using these keys set. Moreover, link is now featured in the program. 
*				He is animated and can interact with the tiles and switch screens when needed. Added pots and boomerang interaction to the program.
*				
*/


import javax.swing.JPanel;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.IOException;
import java.io.File;
import javax.swing.JButton;
import java.awt.Color;
import javax.swing.Timer;
import java.awt.Font;

class View extends JPanel
{
	// JButton b1;
	int scrollPosX;
	int scrollPosY;
	Model model;
	Controller controller;
	BufferedImage tile_image;
	BufferedImage[] images;
	BufferedImage link_image;

	View(Controller c, Model m)
	{
		/*model = m;
		b1 = new JButton("Don't push me");
		b1.addActionListener(c);
		this.add(b1);
		c.setView(this);
		try{
		    this.turtle_image = ImageIO.read(new File("turtle.png"));
		}
		catch(Exception e){
		    e.printStackTrace(System.err);
		    System.exit(1);
		}*/

		model = m;
		controller = c;
		scrollPosX = 0;
		scrollPosY = 0;

		//down 1-7
		//left 8 - 14
		//right 15 - 21
		//up 22 - 28
		/*for(int i = 0; i < 28; i++){
			images[i] = loadImage("images/link" + (i+1) + ".png");
		}*/

		//load tile image
		try{
			this.tile_image = ImageIO.read(new File("images/tile.jpg"));
		}catch(Exception e){
			e.printStackTrace(System.err);
			System.exit(1);
		}
	}

	public static BufferedImage loadImage(String filename){
		BufferedImage image = null;
		try{
			image = ImageIO.read(new File(filename));
		}catch(Exception e){
			e.printStackTrace(System.err);
			System.out.println("Couldn't find " + filename);
			System.exit(1);
		}
		//System.out.println(filename + " is loaded");
		return image;
	}

	void setModel(Model m){
		model = m;
	}

	// void removeButton(){
	// 	this.remove(b1);
	// 	this.repaint();
	// }

	public void scrollUp(){
		if(scrollPosY >= 500){
			scrollRecursivelyY(5, true);
		}
	}

	public void scrollDown(){
		if(scrollPosY < 500){	
			scrollRecursivelyY(5, false);
		}
	}

	public void scrollLeft(){
		if(scrollPosX >= 700){
			scrollRecursivelyX(7, true);
		}
	}

	public void scrollRight(){
		if(scrollPosX < 700){
			scrollRecursivelyX(7, false);
		}
	}

	private void scrollRecursivelyY(int count, boolean isUp) {
		if(isUp == true){
		    if (count > 0) {
		        Timer timer = new Timer(400, event -> {
		            scrollPosY -= 100;
		            this.repaint();
		            scrollRecursivelyY(count - 1, true);
		        });
		        timer.setRepeats(false);
		        timer.start();
		    }
		}else{
			if (count > 0) {
		        Timer timer = new Timer(400, event -> {
		            scrollPosY += 100;
		            this.repaint();
		            scrollRecursivelyY(count - 1, false);
		        });
		        timer.setRepeats(false);
		        timer.start();
		    }
		}
	}

	private void scrollRecursivelyX(int count, boolean isLeft) {
		if(isLeft == true){
		    if (count > 0) {
		        Timer timer = new Timer(500, event -> {
		            scrollPosX -= 100;
		            this.repaint();
		            scrollRecursivelyX(count - 1, true);
		        });
		        timer.setRepeats(false);
		        timer.start();
		    }
		}else{
			if (count > 0) {
		        Timer timer = new Timer(500, event -> {
		            scrollPosX += 100;
		            this.repaint();
		            scrollRecursivelyX(count - 1, false);
		        });
		        timer.setRepeats(false);
		        timer.start();
		    }
		}
	}

	public void paintComponent(Graphics g){
		g.setColor(new Color(128, 255, 255));
	    g.fillRect(0, 0, this.getWidth(), this.getHeight());

	    //draw link using his class
	    //model.link.draw(g, scrollPosX, scrollPosY);

	    //draw tiles
		for(int i = 0; i < model.sprites.size(); i++)
		{
			//model.tiles.get(i).drawTile(g, tile_image, scrollPosX, scrollPosY);
			model.sprites.get(i).draw(g, scrollPosX, scrollPosY);
			// Tile t = model.tiles.get(i);
			// g.drawImage(tile_image, t.x - scrollPosX, t.y - scrollPosY, t.w, t.h, null);
		}

		if(controller.isEdit){
	    	g.setColor(new Color(255, 255, 0));
	    	g.setFont(new Font("default", Font.BOLD, 16));
	    	g.drawString("EDITING MODE IS ENABLED", this.getWidth()-250, this.getHeight()-20);
	    }
	}
}
