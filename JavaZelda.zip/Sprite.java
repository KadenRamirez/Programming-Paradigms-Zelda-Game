/*
* Kaden Ramirez
* 3/10/2023
* Link and map interaction- create a map using tiles. This map could then be saved, loaded, and adjusted as necessary by a click of the mouse
*				but only in the edit mode. Moreover, using the w,a,x,d keys you can move the view up, left, down, and right respectively.
*				The map will also not let you go out of the bounds using these keys set. Moreover, link is now featured in the program. 
*				He is animated and can interact with the tiles and switch screens when needed. Added pots and boomerang interaction to the program.
*				
*/

import java.awt.Graphics;
import java.awt.image.BufferedImage;

public abstract class Sprite{
	int x, y, w, h, speed, prevx, prevy;
	BufferedImage image;

	public abstract void update();
	public abstract void draw(Graphics g, int scrollPosX, int scrollPosY);
	public abstract Json marshal();

	public boolean isCollision(Sprite s){
		if(this.x + this.w < s.x){
			return false;
		}
		if(this.x > s.x + s.w){
			return false;
		}
		if(this.y + this.h < s.y){
			return false;
		}
		if(this.y > s.y + s.h){
			return false;
		}
		return true;
	}

	public boolean isClicked(int x, int y){
		if(x >= this.x && x <= this.x + this.w && y >= this.y && y <= this.y + this.h){
			return true;
		}
		return false;
	}

	/*public boolean isClicked(){
		return false;
	}*/

	public boolean isLink(){
		return false;
	}

	public boolean isTile(){
		return false;
	}

	public boolean isPot(){
		return false;
	}

	public boolean isBoomerang(){
		return false;
	}

	public void setPreviousCoordinates(int x, int y){
		this.prevx = x;
		this.prevy = y;
	}
}