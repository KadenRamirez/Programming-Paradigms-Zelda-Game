/*
* Kaden Ramirez
* 3/10/2023
* Link and map interaction- create a map using tiles. This map could then be saved, loaded, and adjusted as necessary by a click of the mouse
*               but only in the edit mode. Moreover, using the w,a,x,d keys you can move the view up, left, down, and right respectively.
*               The map will also not let you go out of the bounds using these keys set. Moreover, link is now featured in the program. 
*               He is animated and can interact with the tiles and switch screens when needed. Added pots and boomerang interaction to the program.
*               
*/

import java.awt.Graphics;
import java.awt.image.BufferedImage;

public class Pot extends Sprite{

	// int w = 50;
    // int h = 50;
	// int x;
	// int y;
    // BufferedImage tile_image;
    boolean isBroken;

	public Pot(int x, int y) {
        this.x = x;
        this.y = y;
        w = 40;
        h = 40;
        speed = 0;
        System.out.println("the pot constructor is being called");
        image = null;
        if(image == null){
            System.out.println("The pot image is being loaded");
            image = View.loadImage("images/pot.png");
        }
    }

    public void potBreak(){
        isBroken = !isBroken;
        image = View.loadImage("images/broken_pot.png");
    }

    public boolean isClicked(int x, int y){
    	if(this.x == x && this.y == y){
    		return true;
    	}
    	return false;
    }

    //marshal constructor
    public Json marshal()
    {
        Json ob = Json.newObject();
        ob.add("x", x);
        ob.add("y", y);
        return ob;
    }

    //unmarshal constructor
    Pot(Json ob)
    {
        x = (int)ob.getLong("x");
        y = (int)ob.getLong("y");
        w = 40;
        h = 40;
        speed = 0;
        //System.out.println("this is t.x: " + x + " this is t.y: " + y + " this is t.w: " + w + " this is t.h: " + h);
        image = null;
        if(image == null){
            image = View.loadImage("images/pot.png");
        }
    }

    public void slide(int dir){

    }

    public void draw(Graphics g, int scrollPosX, int scrollPosY) {
        g.drawImage(image, x - scrollPosX, y - scrollPosY, w, h, null);
    }

    public boolean isPot(){
        return true;
    }

    public void setPreviousCoordinates(int x, int y){
        this.prevx = x;
        this.prevy = y;
    }

    public void timer(){
        speed -= 1;
    }

    public void update(){
        if(speed == 1){
            x -= 4;
        }if(speed == 2){
            x += 4;
        }
        if(speed == 3){
            y -= 4;
        }
        if(speed == 4){
            y += 4;
        }
        if(speed <= -1){
            image = View.loadImage("images/pot_broken.png");
            timer();
        }
    }

    public boolean getIsBroken(){
        return isBroken;
    }
    public void setIsBroken(boolean broke){
        isBroken = broke;
    }

}