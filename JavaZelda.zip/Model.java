/*
* Kaden Ramirez
* 3/10/2023
* Link and map interaction- create a map using tiles. This map could then be saved, loaded, and adjusted as necessary by a click of the mouse
*				but only in the edit mode. Moreover, using the w,a,x,d keys you can move the view up, left, down, and right respectively.
*				The map will also not let you go out of the bounds using these keys set. Moreover, link is now featured in the program. 
*				He is animated and can interact with the tiles and switch screens when needed. Added pots and boomerang interaction to the program.
*				
*/

import java.util.ArrayList;
import java.util.Iterator;

class Model{
	//ArrayList<Tile> tiles;
	//link is the sprites.get(0)
	ArrayList<Sprite> sprites;
	Link link;

	Model()
	{
		//tiles = new ArrayList<Tile>();
		sprites = new ArrayList<Sprite>();
		link = new Link(200, 200);
		sprites.add(link);
	}

	public void update()
	{
		//System.out.println(sprites.size());
		Iterator<Sprite> iter = sprites.iterator();
		int removeBoomerang = -1;
		while(iter.hasNext()){
			Sprite s1 = iter.next();
			s1.update();
			Iterator<Sprite> iter2 = sprites.iterator();
			for(int i = 0; iter2.hasNext(); i++){
				Sprite s2 = iter2.next();
				if(s1.isCollision(s2)){
					if(s1.isLink() && s2.isTile()){
						s1.x = s1.prevx;
						s1.y = s1.prevy;
					}
					if(s1.isLink() && s2.isPot()){
						s1.x = s1.prevx;
						s1.y = s1.prevy;
						if(link.heading.direction == 1){
							s2.speed = 1;
						}
						if(link.heading.direction == 2){
							s2.speed = 2;
						}
						if(link.heading.direction == 3){
							s2.speed = 3;
						}
						if(link.heading.direction == 0){
							s2.speed = 5;
						}
					}
					if(s1.isTile() && s2.isPot()){
						s2.x = s2.prevx;
						s2.y = s2.prevy;
						if(s2.speed > -2){
							s2.speed = -1;
						}
						//System.out.println("pot is colliding with tile");
						//s2.setIsBroken(true);
					}
					if(s1.isTile() && s2.isBoomerang()){
						removeBoomerang = i;
					}
					if(s1.isPot() && s2.isBoomerang()){
						s1.x = s1.prevx;
						s1.y = s1.prevy;
						if(s1.speed > -2){
							s1.speed = -1;
						}
						//System.out.println("pot is colliding with tile");
						removeBoomerang = i;
					}
				}
			}
		}
		//-1 isn't an index that exists and means a boomerang needs to be removed.
		if(removeBoomerang != -1){
			sprites.remove(removeBoomerang);
		}
		removeBoomerang = -1;
		for(int i = 0; i < sprites.size(); i++){
			if(sprites.get(i).isPot() && sprites.get(i).speed == -8){
				sprites.remove(i);
			}
		}
	}

	public void addTile(int x, int y){
		Tile t = new Tile(x, y);
		sprites.add(t);
	}

	public void removeTile(int x, int y){
		for(int i = 0; i < sprites.size(); i++)
		{
			if(sprites.get(i).isTile()){
				Sprite s = sprites.get(i);
				if(s.isClicked(x, y)){
					sprites.remove(i);
				}
			}
		}
	}

	public void addPot(int x, int y){
		Pot p = new Pot(x, y);
		sprites.add(p);
	}

	public void addBoomerang(int x, int y){
		Boomerang b = new Boomerang(x, y, link.heading.direction);
		sprites.add(b);
	}

	public void removePot(int x, int y){
		for(int i = 0; i < sprites.size(); i++)
		{
			if(sprites.get(i).isPot()){
				Sprite s = sprites.get(i);
				if(s.isClicked(x, y)){
					sprites.remove(i);
				}
			}
		}
	}

	//marshal constructor
	public Json marshal()
    {
        Json ob = Json.newObject();
        Json tmpListTiles = Json.newList();
        ob.add("tiles", tmpListTiles);
        Json tmpListPots = Json.newList();
        ob.add("pots", tmpListPots);
        for(int i = 0; i < sprites.size(); i++){
        	if(sprites.get(i).isTile()){
            	tmpListTiles.add(sprites.get(i).marshal());
        	}
        	if(sprites.get(i).isPot()){
        		tmpListPots.add(sprites.get(i).marshal());
        	}
        }
        ob.save("map.json");
        return ob;
    }

    //unmarshal constructor
    Model(Json ob)
    {
    	// ob.load("map.json");
    	sprites = new ArrayList<Sprite>();
  		link = new Link(200, 200);
  		sprites.add(link);
        Json tmpListTiles = ob.get("tiles");
        Json tmpListPots = ob.get("pots");
        for(int i = 0; i < tmpListTiles.size(); i++){
        	//System.out.println("this is t.x: " + tmpList.get(i));
            sprites.add(new Tile(tmpListTiles.get(i)));
        }
        for(int i = 0; i < tmpListPots.size(); i++){
        	//System.out.println("this is t.x: " + tmpList.get(i));
            sprites.add(new Pot(tmpListPots.get(i)));
        }
    }

	public void setDestination(int x, int y)
	{
		// this.dest_x = x;
		// this.dest_y = y;
	}


	/*public boolean isCollision(Sprite t){
		//link.x is left side of link
		//link.x + link.w is right side of link
		//System.out.println("this is link.x: " + link.x + " and this is link.y: " + link.y);
		//System.out.println("this is tile.x: " + t.x + " this is tile.y: " + t.y + " this is tile.w: " + t.w + " this is tile.h: " + t.h);

		//t.x is not tile.x value but sprite.x I don't think it's passing the value to the x in sprite
		if(link.x + link.w < t.x){
			return false;
		}
		if(link.x > t.x + t.w){
			return false;
		}
		if(link.y + link.h < t.y){
			return false;
		}
		if(link.y > t.y + t.h){
			return false;
		}
		//System.out.println("is colliding");
		//System.out.println(sprites.size());
		return true;
	}*/
}