import pygame
import time

from pygame.locals import*
from time import sleep

class Sprite:
    def __init__(self, x1, y1, w1, image_url):
        self.x = x1
        self.y = y1
        self.w = w1
        self.image = pygame.image.load(image_url)

    def move(self, dx, dy):
        self.x += dx
        self.y += dy

    def isCollision(self, s):
        if self.x + self.w < s.x:
            return False
        if self.x > s.x + s.w:
            return False
        if self.y + self.w < s.y:
            return False
        if self.y > s.y + s.w:
            return False
        # print("something is colliding")
        return True

class Tile(Sprite):
    def __init__(self, x, y, w, image_url):
        super().__init__(x, y, w, image_url)
        self.isLink = False
        self.isTile = True
        self.isPot = False
        self.isBoomerang = False

    def update(self): # sit_still
        pass

    def drawSelf(self, screen, scrollPosX, scrollPosY):
        screen.blit(self.image, (self.x - scrollPosX, self.y - scrollPosY))

class Link(Sprite):
	def __init__(self, x, y, w, image_url):
		super().__init__(x, y, w, image_url)
		self.images = []
		for i in range (1,29):
			img = pygame.image.load("images/link" + str(i) + ".png")
			self.images.append(img)
		self.prevx = x
		self.prevy = y
		self.isLink = True
		self.isTile = False
		self.isPot = False
		self.isBoomerang = False
		self.direction = 0
		self.currentImage = 0
	
	def update(self):
		pass

	def setPreviousCoordinates(self, x, y):
		self.prevx = self.x
		self.prevy = self.y

	def animate(self, dir):
		# down 1-7
		# left 8 - 14
		# right 15 - 21
		# up 22 - 28

		self.direction = dir
		self.currentImage += 1
		if(self.currentImage >= 7):
			self.currentImage = 0

	def drawSelf(self, screen, scrollPosX, scrollPosY):
		screen.blit(self.images[self.currentImage + 7 * self.direction], (self.x - scrollPosX, self.y - scrollPosY))

class Pot(Sprite):
	def __init__(self, x, y, w, image_url):
		super().__init__(x, y, w, image_url)
		self.isLink = False
		self.isTile = False
		self.isPot = True
		self.isBoomerang = False
		self.speed = 0
		self.prevx = x
		self.prevy = y
		
	def update(self): # sit_still
		self.prevx = self.x
		self.prevy = self.y
		if(self.speed == 1):
			self.x -= 4
		if(self.speed == 2):
			self.x += 4
		if(self.speed == 3):
			self.y -= 4
		if(self.speed == 4):
			self.y += 4
		if(self.speed <= -1):
			self.speed -= 1
			self.image = pygame.image.load("images/pot_broken.png")
        
	def drawSelf(self, screen, scrollPosX, scrollPosY):
		screen.blit(self.image, (self.x - scrollPosX, self.y - scrollPosY))

class Boomerang(Sprite):
	def __init__(self, x, y, w, image_url, dir):
		super().__init__(x, y, w, image_url)
		self.speed = dir
		self.isClicked = False
		self.isLink = False
		self.isTile = False
		self.isPot = False
		self.isBoomerang = True
	
	def update(self):
		if(self.speed == 1):
			self.x -= 8
		if(self.speed == 2):
			self.x += 8
		if(self.speed == 3):
			self.y -= 8
		if(self.speed == 0):
			self.y += 8

	def drawSelf(self, screen, scrollPosX, scrollPosY):
		screen.blit(self.image, (self.x - scrollPosX, self.y - scrollPosY))
	

class Model():
	def __init__(self):
		self.dest_x = 0
		self.dest_y = 0
		self.sprites = []
		self.link = Link(200, 200, 80, "images/link1.png")
		self.sprites.append(self.link)
		self.sprites.append(Tile(650, 450, 50 , "images/tile.jpg"))
		self.sprites.append(Tile(700, 450, 50 , "images/tile.jpg"))
		self.sprites.append(Tile(700, 500, 50 , "images/tile.jpg"))
		self.sprites.append(Tile(650, 500, 50 , "images/tile.jpg"))
		self.sprites.append(Pot(200, 100 , 50, "images/pot.png"))
		for i in range (0, 28):
			if(i != 0):
				self.sprites.append(Tile(i * 50, 0, 50 , "images/tile.jpg"))
				self.sprites.append(Tile(0, i * 50, 50 , "images/tile.jpg"))
				self.sprites.append(Tile(0 + i * 50, 950, 50 , "images/tile.jpg"))
				self.sprites.append(Tile(1350, 0 + i * 50, 50 , "images/tile.jpg"))
				self.sprites.append(Tile(1350, 450 + i * 50, 50 , "images/tile.jpg"))
			else:
				self.sprites.append(Tile(0, 0, 50 , "images/tile.jpg"))
				self.sprites.append(Tile(1400, 1000, 50 , "images/tile.jpg"))

	def update(self):
		for i, s1 in enumerate(self.sprites):
			s1.update()
			for j, s2 in enumerate(self.sprites):
				if(s1.isCollision(s2)):
					if(s1.isLink and s2.isTile):
						print("link is colliding")
						s1.x = s1.prevx
						s1.y = s1.prevy
					if(s1.isLink and s2.isPot):
						s1.x = s1.prevx
						s1.y = s1.prevy
						if(self.link.direction == 1):
							s2.speed = 1
						if(self.link.direction == 2):
							s2.speed = 2
						if(self.link.direction == 3):
							s2.speed = 3
						if(self.link.direction == 0):
							s2.speed = 4
					if(s1.isTile and s2.isPot):
						s2.x = s2.prevx
						s2.y = s2.prevy
						if (s2.speed > -2):
							s2.speed = -1
					if(s1.isPot and s2.isBoomerang):
						s2.speed = -1
						if(s1.speed > -2):
							s1.speed = -1
					if(s1.isTile and s2.isBoomerang):
						s2.speed = -1
					
			if (s1.isPot and s1.speed == -8):
				self.sprites.pop(i)
			if (s1.isBoomerang and s1.speed == -1):
				self.sprites.pop(i)
			

class View():
	def __init__(self, model):
		screen_size = (700,500)
		self.screen = pygame.display.set_mode(screen_size, 32)
		# self.turtle_image = pygame.image.load("images/link1.png")
		self.model = model
		# self.model.rect = self.turtle_image.get_rect()
		self.scrollPosX = 0
		self.scrollPosY = 0
		#self.tile = Tile(200, 50, 32, "images/tile.png")


	def update(self):
		self.screen.fill([0,200,100])
		# self.screen.blit(self.turtle_image, self.model.rect)
		for sprite in self.model.sprites:
			sprite.drawSelf(self.screen, self.scrollPosX, self.scrollPosY)
		pygame.display.flip()
	
	def scrollRight(self):
		self.scrollPosX += 700
	def scrollLeft(self):
		self.scrollPosX -= 700
	def scrollDown(self):
		self.scrollPosY += 500
	def scrollUp(self):
		self.scrollPosY -= 500

class Controller():
	def __init__(self, model, view):
		self.model = model
		self.view = view
		self.keep_going = True

	def update(self):
		for event in pygame.event.get():
			if event.type == QUIT:
				self.keep_going = False
			elif event.type == KEYDOWN:
				if event.key == K_ESCAPE:
					self.keep_going = False
		keys = pygame.key.get_pressed()
		self.model.link.setPreviousCoordinates(self.model.link.x, self.model.link.y)
		if keys[K_LEFT]:
			self.model.link.x -= 4
			self.model.link.animate(1)
			if(self.model.link.x < 700 and self.model.link.prevx >= 700):
				self.view.scrollLeft()
		if keys[K_RIGHT]:
			self.model.link.x += 4
			self.model.link.animate(2)
			if(self.model.link.x + self.model.link.w > 700 and self.model.link.prevx + self.model.link.w <= 700):
				self.view.scrollRight()
		if keys[K_UP]:
			self.model.link.y -= 4
			self.model.link.animate(3)
			if(self.model.link.y < 500 and self.model.link.prevy >= 500):
				self.view.scrollUp()
		if keys[K_DOWN]:
			# print("this is happening")
			self.model.link.y += 4
			self.model.link.animate(0)
			if(self.model.link.y + self.model.link.w > 500 and self.model.link.prevy + self.model.link.w <= 500):
				self.view.scrollDown()
		if keys[K_LCTRL]:
			print("boomerang")
			self.model.sprites.append(Boomerang((self.model.link.x + 30), (self.model.link.y + 30), 50, "images/boomerang3.png", self.model.link.direction))

print("Use the arrow keys to move. Press Esc to quit.")
pygame.init()
m = Model()
v = View(m)
c = Controller(m, v)
while c.keep_going:
	c.update()
	m.update()
	v.update()
	sleep(0.04)
print("Goodbye")